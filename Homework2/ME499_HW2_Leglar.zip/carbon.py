#!/usr/bin/env python3
from datetime import datetime
import time
import requests
import json
import os.path
import matplotlib as plt


def get_current_day():  # Problem 1
    date = time.time()
    dt_object = datetime.fromtimestamp(date)
    return dt_object.strftime('%Y-%m-%d')  # %H:%M:%S


data_cache = []  # Problem 2


def query_carbon(date=get_current_day(), use_cache=True):

    headers = {'Accept': 'application/json'}
    url = 'https://api.carbonintensity.org.uk/intensity/date/' + str(date)

    if use_cache:

        if os.path.exists(f"data/carbon_{date}.json"):
            with open(f"data/carbon_{date}.json", 'r') as f:
                data = f.read()
                data = json.loads(data)
            print('data found on os')

        else:
            r = requests.get(url, params={}, headers=headers)
            if r.status_code == 200:
                data = json.loads(r.content.decode('utf-8'))
                print('data loaded from api')
                with open(f'data/carbon_{date}.json', 'w') as f:
                    json.dump(data, f)

            else:
                return 'error: ' + str(r.status_code)

    else:
        r = requests.get(url, params={}, headers=headers)
        if r.status_code == 200:
            data = json.loads(r.content.decode('utf-8'))
            with open(f'data/carbon_{date}.json', 'w') as f:
                json.dump(data, f)
        print('use_cache turned off, pulled data from api')
    return data


def plot_carbon(date=get_current_day()):  # Problem 3 (incomplete)
    data = query_carbon(date, True)

    label_list = []
    intensity = []
    forecast_carbon = []
    actual_carbon = []
    data_time = []

    for i in data["data"]:
        intensity.append(i['intensity'])
    print(intensity)
        # for j in data[i]:
        #     print(j["intensity"])
        # label_list = label['intensity']
        # label_list.append(label['intensity'])
        # for j in data[i]:
        #     # print(j)
        #     for k in data[j]:
        #         print(data['intensity'])

    # print(type(label_list))
    # print(label_list)
        # for item in label_list:
        #     carbon_data = carbon_data.append(item)
        #     for data1 in label_list['forecast']:
        #         forecast_carbon = forecast_carbon.append(i)
        #     print(forecast_carbon)
        #     for j in label_list['actual']:
        #         actual_carbon = actual_carbon.append(j)
        #     print(actual_carbon)

    # print(label_list)
    return forecast_carbon, actual_carbon, data_time


if __name__ == '__main__':
    print(plot_carbon())

    # Problem 3 unfinished so plotting not complete
    plt.plot(data_time, forecast_carbon)
    plt.plot(data_time, actual_carbon)