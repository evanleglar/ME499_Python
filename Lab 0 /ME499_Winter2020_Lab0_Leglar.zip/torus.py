#!/usr/bin/env python
from math import *
rout = 4
rin = 3

R = (rout + rin)/2
r = (rout - rin)/2

Volume = 2 * (pi ** 2) * R * (r ** 2)

print(Volume)