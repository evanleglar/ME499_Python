#!/usr/bin/env python
from math import *

r = 3
h = 5

volume = r * r * pi * h

print(volume)
